{ pkgs }: {
  deps = [
    (pkgs.php.withExtensions ({ enabled, all }: enabled ++ (with all; [ curl mbstring pdo_sqlite ])))
    pkgs.python3
  ];
}
