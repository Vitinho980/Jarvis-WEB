<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

function ask_jarvis_ai(string $prompt, array $history, array $memories): string {
    $url = env_value('AI_SERVICE_URL', 'http://127.0.0.1:8765/chat');
    $token = env_value('AI_SERVICE_TOKEN');
    if ($token === '') {
        return 'O serviço interno de IA não recebeu o token de comunicação. Reinicie o projeto pelo botão Run para gerar o token automaticamente.';
    }

    $payload = json_encode([
        'prompt' => $prompt,
        'history' => $history,
        'memories' => $memories
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    if ($payload === false) {
        return 'Não foi possível preparar a mensagem para o serviço de IA.';
    }

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'X-Jarvis-Token: ' . $token
        ],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 3,
        CURLOPT_TIMEOUT => 70
    ]);
    $response = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($response === false) {
        return 'Não consegui alcançar o serviço interno de IA. Confira se os serviços Python e PHP foram iniciados pelo start.sh.';
    }

    $decoded = json_decode($response, true);
    if ($status < 200 || $status >= 300 || !is_array($decoded) || empty($decoded['answer'])) {
        $detail = is_array($decoded) ? ($decoded['error'] ?? 'resposta inválida') : 'resposta inválida';
        return clean_string((string)$detail, 500) ?: 'O serviço de IA retornou uma resposta inválida.';
    }
    return clean_string((string)$decoded['answer'], 6000);
}
