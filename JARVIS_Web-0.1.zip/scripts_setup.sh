#!/usr/bin/env bash
set -euo pipefail
echo "Instalando dependências para Ubuntu/Debian..."
sudo apt update
sudo apt install -y php php-cli php-sqlite3 php-curl php-mbstring python3
echo
echo "Dependências do sistema instaladas."
echo "Copie .env.example para .env, edite os segredos e siga o README.md."
