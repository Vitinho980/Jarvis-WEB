#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

# Carrega .env apenas para desenvolvimento local. Variáveis já fornecidas pelo
# Replit Secrets sempre têm prioridade e nunca são substituídas por este arquivo.
if [[ -f .env ]]; then
  while IFS= read -r line || [[ -n "$line" ]]; do
    line="${line#"${line%%[![:space:]]*}"}"
    [[ -z "$line" || "$line" == \#* || "$line" != *=* ]] && continue
    key="${line%%=*}"
    value="${line#*=}"
    key="${key//[[:space:]]/}"
    if [[ "$key" =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]] && [[ ! -v "$key" ]]; then
      value="${value%$'\r'}"
      value="${value#\"}"; value="${value%\"}"
      value="${value#\'}"; value="${value%\'}"
      export "$key=$value"
    fi
  done < .env
fi

# Cria um token interno efêmero compartilhado pelos dois processos.
# A chave OPENAI_API_KEY vem do Replit Secrets e não é exibida.
if [[ -z "${AI_SERVICE_TOKEN:-}" ]]; then
  export AI_SERVICE_TOKEN="$(python3 -c 'import secrets; print(secrets.token_urlsafe(32))')"
fi
export AI_SERVICE_PORT="${AI_SERVICE_PORT:-8765}"
WEB_PORT="${PORT:-8080}"

if ! command -v php >/dev/null 2>&1; then
  echo "ERRO: PHP não encontrado. Adicione PHP às dependências do Replit." >&2
  exit 1
fi
if ! php -m | grep -qi '^pdo_sqlite$'; then
  echo "ERRO: extensão pdo_sqlite ausente no PHP." >&2
  exit 1
fi
if ! php -m | grep -qi '^mbstring$'; then
  echo "ERRO: extensão mbstring ausente no PHP." >&2
  exit 1
fi
if ! php -m | grep -qi '^curl$'; then
  echo "ERRO: extensão curl ausente no PHP." >&2
  exit 1
fi

python3 ai_service/server.py &
AI_PID=$!
cleanup() {
  kill "$AI_PID" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

# Aguarda o serviço interno iniciar antes de publicar a interface PHP.
python3 - <<'PY'
import os
import time
import urllib.request

url = f"http://127.0.0.1:{os.environ.get('AI_SERVICE_PORT', '8765')}/health"
for _ in range(30):
    try:
        with urllib.request.urlopen(url, timeout=1) as response:
            if response.status == 200:
                print("JARVIS AI: serviço interno pronto.")
                break
    except Exception:
        time.sleep(0.5)
else:
    raise SystemExit("ERRO: o serviço Python de IA não iniciou corretamente.")
PY

if [[ -z "${OPENAI_API_KEY:-}" ]]; then
  echo "AVISO: OPENAI_API_KEY não configurada em Tools → Secrets; o chat exibirá instruções de configuração." >&2
fi

echo "JARVIS Web disponível na porta ${WEB_PORT}."
php -S "0.0.0.0:${WEB_PORT}" -t public
