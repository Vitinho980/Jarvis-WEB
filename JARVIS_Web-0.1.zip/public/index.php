<?php
declare(strict_types=1);
require_once __DIR__ . '/../backend/bootstrap.php';
$csrf = htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8');
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="<?= $csrf ?>">
  <meta name="theme-color" content="#08111f">
  <title>J.A.R.V.I.S. — Assistente pessoal</title>
  <link rel="stylesheet" href="assets/app.css">
</head>
<body>
<div class="ambient ambient-a"></div><div class="ambient ambient-b"></div>
<div id="authView" class="auth-view">
  <div class="auth-card">
    <div class="brand-mark">J<span>.</span></div>
    <p class="eyebrow">PERSONAL INTELLIGENCE SYSTEM</p>
    <h1 id="authTitle">Acesse seu JARVIS</h1>
    <p class="muted" id="authSubtitle">Entre na sua conta para continuar.</p>
    <form id="authForm" class="auth-form">
      <label id="nameField" class="field hidden">Seu nome
        <input id="displayName" name="display_name" autocomplete="name" maxlength="70" placeholder="Como devo chamar você?">
      </label>
      <label class="field">E-mail
        <input id="email" name="email" type="email" autocomplete="username" required maxlength="190" placeholder="voce@email.com">
      </label>
      <label class="field">Senha
        <input id="password" name="password" type="password" autocomplete="current-password" required minlength="10" placeholder="Mínimo de 10 caracteres">
      </label>
      <button class="primary-button full" id="authSubmit" type="submit">Entrar <span>→</span></button>
    </form>
    <p class="auth-error" id="authError" role="alert"></p>
    <button class="text-button" id="authSwitch" type="button">Ainda não tem conta? Criar conta</button>
    <p class="tiny-note">Suas conversas e memórias ficam vinculadas à sua conta.</p>
  </div>
</div>

<div id="appView" class="app-shell hidden">
  <aside class="sidebar">
    <div class="sidebar-brand">
      <div class="mini-mark">J</div>
      <div><strong>J.A.R.V.I.S.</strong><small>PERSONAL SYSTEM</small></div>
    </div>
    <button class="new-chat-button" id="newChatButton"><span>＋</span> Nova conversa</button>
    <div class="sidebar-label">ESPAÇO PESSOAL</div>
    <button class="nav-button active" data-panel="chatPanel"><span>◈</span> Assistente</button>
    <button class="nav-button" data-panel="memoryPanel"><span>⌘</span> Minha memória</button>
    <div class="sidebar-spacer"></div>
    <div class="connection-card">
      <span class="status-dot"></span>
      <div><strong id="connectionLabel">Sistema conectado</strong><small id="connectionSub">Pronto para conversar</small></div>
    </div>
    <div class="profile-row">
      <div class="avatar" id="userAvatar">U</div>
      <div class="profile-info"><strong id="userName">Usuário</strong><small id="userEmail">conta</small></div>
      <button class="icon-button" id="logoutButton" title="Sair da conta" aria-label="Sair">↗</button>
    </div>
  </aside>

  <main class="main-area">
    <header class="topbar">
      <div><div class="eyebrow">ASSISTENTE PESSOAL</div><h2 id="pageTitle">Como posso ajudar?</h2></div>
      <div class="topbar-right"><span class="secure-label">⌑ CONTA PRIVADA</span><button id="voiceToggle" class="voice-toggle" type="button"><span>◖</span> Voz desativada</button></div>
    </header>

    <section id="chatPanel" class="panel chat-panel">
      <div class="chat-content" id="chatContent">
        <div id="welcome" class="welcome">
          <div class="core-orb"><div class="orb-ring ring-one"></div><div class="orb-ring ring-two"></div><div class="orb-center">J</div></div>
          <p class="eyebrow">SISTEMA ONLINE</p>
          <h1>À sua disposição.</h1>
          <p class="muted welcome-copy">Converse comigo, peça ajuda ou organize suas ideias. Suas memórias ficam sob seu controle.</p>
          <div class="suggestions">
            <button class="suggestion" data-prompt="Explique como você pode me ajudar."><span>✧</span><strong>O que você pode fazer?</strong><small>Conheça minhas funções</small></button>
            <button class="suggestion" data-prompt="Me ajude a organizar minhas tarefas de hoje."><span>◷</span><strong>Organizar meu dia</strong><small>Planejamento e produtividade</small></button>
            <button class="suggestion" data-prompt="Explique inteligência artificial de uma forma simples."><span>⌘</span><strong>Aprender algo novo</strong><small>Explicações claras</small></button>
          </div>
        </div>
        <div id="messages" class="messages" aria-live="polite"></div>
      </div>
      <div class="composer-wrap">
        <form id="chatForm" class="composer">
          <textarea id="messageInput" rows="1" maxlength="4000" placeholder="Escreva uma mensagem para o JARVIS..." aria-label="Mensagem"></textarea>
          <div class="composer-bottom">
            <span class="composer-hint">ENTER para enviar · SHIFT + ENTER para nova linha</span>
            <div class="composer-actions">
              <button type="button" id="micButton" class="round-button" title="Falar" aria-label="Falar">🎙</button>
              <button type="submit" id="sendButton" class="send-button">Enviar <span>↑</span></button>
            </div>
          </div>
        </form>
        <p class="disclaimer">A IA pode cometer erros. Confira informações importantes antes de agir.</p>
      </div>
    </section>

    <section id="memoryPanel" class="panel memory-panel hidden">
      <div class="section-intro">
        <div class="eyebrow">PERSONALIZAÇÃO</div><h1>Sua memória.</h1>
        <p class="muted">Guarde somente as informações que deseja que o JARVIS use em conversas futuras.</p>
      </div>
      <div class="memory-setting">
        <div><strong>Usar minhas memórias nas respostas</strong><p class="muted">Quando desativado, o JARVIS não consulta suas memórias ao responder.</p></div>
        <label class="switch"><input type="checkbox" id="memoryEnabled" checked><span class="slider"></span></label>
      </div>
      <form id="memoryForm" class="memory-form">
        <label class="field">Título<input id="memoryTitle" maxlength="80" required placeholder="Ex.: Meu esporte favorito"></label>
        <label class="field">Informação<textarea id="memoryContent" maxlength="500" rows="3" required placeholder="Escreva exatamente o que deseja guardar..."></textarea></label>
        <button class="primary-button" type="submit">＋ Salvar na memória</button>
      </form>
      <div class="memory-list-header"><h3>Informações salvas</h3><span id="memoryCount" class="count-pill">0 itens</span></div>
      <div id="memoryList" class="memory-list"></div>
    </section>
  </main>
</div>
<div id="toast" class="toast" role="status"></div>
<script src="assets/app.js" defer></script>
</body>
</html>
