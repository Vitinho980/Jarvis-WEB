<?php
declare(strict_types=1);
require_once __DIR__ . '/../backend/bootstrap.php';
require_once __DIR__ . '/../backend/ai_client.php';

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

try {
    if ($method === 'GET' && $action === 'me') {
        $user = current_user();
        json_response([
            'ok' => true,
            'authenticated' => $user !== null,
            'user' => $user,
            'csrf' => $_SESSION['csrf_token']
        ]);
    }

    if ($method === 'GET' && in_array($action, ['history', 'memories'], true)) {
        $user = require_user();
        $userId = (int)$user['id'];
        if ($action === 'history') {
            $stmt = db()->prepare('SELECT id, role, content, created_at FROM chat_messages WHERE user_id = ? ORDER BY id DESC LIMIT 80');
            $stmt->execute([$userId]);
            json_response(['ok' => true, 'messages' => array_reverse($stmt->fetchAll())]);
        }
        $stmt = db()->prepare('SELECT id, title, content, created_at FROM memories WHERE user_id = ? ORDER BY id DESC');
        $stmt->execute([$userId]);
        json_response(['ok' => true, 'memories' => $stmt->fetchAll()]);
    }

    if ($method !== 'POST') json_response(['ok' => false, 'error' => 'Método não permitido.'], 405);
    require_csrf();
    $input = request_json();

    if ($action === 'register') {
        $name = clean_string($input['display_name'] ?? '', 70);
        $email = mb_strtolower(clean_string($input['email'] ?? '', 190), 'UTF-8');
        $password = is_string($input['password'] ?? null) ? $input['password'] : '';
        if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 10) {
            json_response(['ok' => false, 'error' => 'Informe nome, e-mail válido e senha com pelo menos 10 caracteres.'], 422);
        }
        if (strlen($password) > 200) json_response(['ok' => false, 'error' => 'Senha muito longa.'], 422);
        $stmt = db()->prepare('INSERT INTO users(display_name, email, password_hash) VALUES(?, ?, ?)');
        try {
            $stmt->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT)]);
        } catch (PDOException $e) {
            if (str_contains(strtolower($e->getMessage()), 'unique')) {
                json_response(['ok' => false, 'error' => 'Este e-mail já possui uma conta.'], 409);
            }
            throw $e;
        }
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int)db()->lastInsertId();
        json_response(['ok' => true, 'user' => current_user()]);
    }

    if ($action === 'login') {
        $email = mb_strtolower(clean_string($input['email'] ?? '', 190), 'UTF-8');
        $password = is_string($input['password'] ?? null) ? $input['password'] : '';
        $stmt = db()->prepare('SELECT id, password_hash FROM users WHERE email = ?');
        $stmt->execute([$email]);
        $row = $stmt->fetch();
        if (!$row || !password_verify($password, $row['password_hash'])) {
            json_response(['ok' => false, 'error' => 'E-mail ou senha incorretos.'], 401);
        }
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int)$row['id'];
        json_response(['ok' => true, 'user' => current_user()]);
    }

    if ($action === 'logout') {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', [
                'expires' => time() - 42000, 'path' => $params['path'],
                'domain' => $params['domain'], 'secure' => $params['secure'],
                'httponly' => $params['httponly'], 'samesite' => 'Strict'
            ]);
        }
        session_destroy();
        json_response(['ok' => true]);
    }

    $user = require_user();
    $userId = (int)$user['id'];

    if ($action === 'chat') {
        $prompt = clean_string($input['message'] ?? '', 4000);
        if ($prompt === '') json_response(['ok' => false, 'error' => 'Digite uma mensagem.'], 422);

        $insert = db()->prepare('INSERT INTO chat_messages(user_id, role, content) VALUES(?, ?, ?)');
        $insert->execute([$userId, 'user', $prompt]);

        $historyStmt = db()->prepare('SELECT role, content FROM chat_messages WHERE user_id = ? ORDER BY id DESC LIMIT 14');
        $historyStmt->execute([$userId]);
        $history = array_reverse($historyStmt->fetchAll());

        $memories = [];
        if ((int)$user['memory_enabled'] === 1) {
            $memStmt = db()->prepare('SELECT title, content FROM memories WHERE user_id = ? ORDER BY id DESC LIMIT 20');
            $memStmt->execute([$userId]);
            $memories = $memStmt->fetchAll();
        }

        $answer = ask_jarvis_ai($prompt, $history, $memories);
        $save = db()->prepare('INSERT INTO chat_messages(user_id, role, content) VALUES(?, ?, ?)');
        $save->execute([$userId, 'assistant', $answer]);

        json_response(['ok' => true, 'answer' => $answer]);
    }

    if ($action === 'memory_create') {
        $title = clean_string($input['title'] ?? '', 80);
        $memory = clean_string($input['content'] ?? '', 500);
        if ($title === '' || $memory === '') json_response(['ok' => false, 'error' => 'Preencha o título e a informação.'], 422);
        $stmt = db()->prepare('INSERT INTO memories(user_id, title, content) VALUES(?, ?, ?)');
        $stmt->execute([$userId, $title, $memory]);
        json_response(['ok' => true, 'id' => (int)db()->lastInsertId()]);
    }

    if ($action === 'memory_delete') {
        $id = filter_var($input['id'] ?? null, FILTER_VALIDATE_INT);
        if (!$id) json_response(['ok' => false, 'error' => 'Informação inválida.'], 422);
        $stmt = db()->prepare('DELETE FROM memories WHERE id = ? AND user_id = ?');
        $stmt->execute([$id, $userId]);
        json_response(['ok' => true]);
    }

    if ($action === 'memory_toggle') {
        $enabled = !empty($input['enabled']) ? 1 : 0;
        $stmt = db()->prepare('UPDATE users SET memory_enabled = ? WHERE id = ?');
        $stmt->execute([$enabled, $userId]);
        json_response(['ok' => true, 'enabled' => (bool)$enabled]);
    }

    if ($action === 'clear_history') {
        $stmt = db()->prepare('DELETE FROM chat_messages WHERE user_id = ?');
        $stmt->execute([$userId]);
        json_response(['ok' => true]);
    }

    json_response(['ok' => false, 'error' => 'Ação não encontrada.'], 404);

} catch (Throwable $e) {
    error_log('JARVIS API: ' . $e->getMessage());
    json_response(['ok' => false, 'error' => 'Erro interno. Verifique os registros do servidor.'], 500);
}
