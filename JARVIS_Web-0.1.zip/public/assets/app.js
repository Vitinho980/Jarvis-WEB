(() => {
  const $ = (id) => document.getElementById(id);
  const csrf = document.querySelector('meta[name="csrf-token"]').content;
  let isRegister = false;
  let user = null;
  let voiceEnabled = false;
  let recognition = null;
  let busy = false;

  async function api(action, method = "GET", data = null) {
    const options = { method, headers: { "Accept": "application/json" } };
    if (method === "POST") {
      options.headers["Content-Type"] = "application/json";
      options.headers["X-CSRF-Token"] = csrf;
      options.body = JSON.stringify(data || {});
    }
    const response = await fetch(`api.php?action=${encodeURIComponent(action)}`, options);
    const result = await response.json().catch(() => ({ ok: false, error: "Resposta inválida do servidor." }));
    if (!response.ok || result.ok === false) throw new Error(result.error || "Erro na solicitação.");
    return result;
  }

  function toast(message) {
    const node = $("toast");
    node.textContent = message;
    node.classList.add("show");
    window.clearTimeout(toast.timer);
    toast.timer = window.setTimeout(() => node.classList.remove("show"), 3200);
  }

  function setAuthMode(register) {
    isRegister = register;
    $("authTitle").textContent = register ? "Crie sua conta" : "Acesse seu JARVIS";
    $("authSubtitle").textContent = register ? "Seu espaço pessoal começa aqui." : "Entre na sua conta para continuar.";
    $("nameField").classList.toggle("hidden", !register);
    $("displayName").required = register;
    $("password").autocomplete = register ? "new-password" : "current-password";
    $("password").placeholder = register ? "Pelo menos 10 caracteres" : "Sua senha";
    $("authSubmit").innerHTML = register ? "Criar minha conta <span>→</span>" : "Entrar <span>→</span>";
    $("authSwitch").textContent = register ? "Já tem uma conta? Entrar" : "Ainda não tem conta? Criar conta";
    $("authError").textContent = "";
  }

  async function showApp() {
    $("authView").classList.add("hidden");
    $("appView").classList.remove("hidden");
    $("userName").textContent = user.display_name;
    $("userEmail").textContent = user.email;
    $("userAvatar").textContent = (user.display_name || "U").trim().charAt(0).toUpperCase();
    $("memoryEnabled").checked = Number(user.memory_enabled) === 1;
    await Promise.all([loadHistory(), loadMemories()]);
  }

  function renderMessage(role, content, id = null) {
    $("welcome").classList.add("hidden");
    const item = document.createElement("article");
    item.className = `message ${role}`;
    if (id !== null) item.dataset.id = id;
    const avatar = document.createElement("div");
    avatar.className = "message-avatar";
    avatar.textContent = role === "assistant" ? "J" : $("userAvatar").textContent;
    const body = document.createElement("div");
    body.className = "message-body";
    const label = document.createElement("div");
    label.className = "message-label";
    label.textContent = role === "assistant" ? "JARVIS" : "VOCÊ";
    const text = document.createElement("div");
    text.className = "message-text";
    text.textContent = content;
    body.append(label, text);
    if (role === "assistant") {
      const actions = document.createElement("div");
      actions.className = "message-actions";
      const speak = document.createElement("button");
      speak.type = "button"; speak.textContent = "Ouvir resposta";
      speak.addEventListener("click", () => speakText(content));
      actions.append(speak);
      body.append(actions);
    }
    item.append(avatar, body);
    $("messages").append(item);
    $("chatContent").scrollTop = $("chatContent").scrollHeight;
    return item;
  }

  async function loadHistory() {
    const result = await api("history");
    $("messages").replaceChildren();
    if (!result.messages.length) {
      $("welcome").classList.remove("hidden");
      return;
    }
    $("welcome").classList.add("hidden");
    result.messages.forEach(m => renderMessage(m.role, m.content, m.id));
  }

  async function loadMemories() {
    const result = await api("memories");
    $("memoryList").replaceChildren();
    $("memoryCount").textContent = `${result.memories.length} ${result.memories.length === 1 ? "item" : "itens"}`;
    if (!result.memories.length) {
      const empty = document.createElement("div");
      empty.className = "empty-memory";
      empty.textContent = "Nenhuma memória salva. Adicione uma informação que você queira que o JARVIS lembre.";
      $("memoryList").append(empty);
      return;
    }
    result.memories.forEach(memory => {
      const card = document.createElement("div");
      card.className = "memory-card";
      const copy = document.createElement("div");
      const title = document.createElement("strong");
      title.textContent = memory.title;
      const text = document.createElement("p");
      text.textContent = memory.content;
      copy.append(title, text);
      const remove = document.createElement("button");
      remove.className = "delete-button"; remove.type = "button"; remove.textContent = "Excluir";
      remove.addEventListener("click", async () => {
        if (!window.confirm("Apagar esta memória?")) return;
        try { await api("memory_delete", "POST", { id: Number(memory.id) }); await loadMemories(); toast("Memória apagada."); }
        catch (e) { toast(e.message); }
      });
      card.append(copy, remove);
      $("memoryList").append(card);
    });
  }

  async function sendMessage(text) {
    if (busy || !text.trim()) return;
    busy = true;
    $("sendButton").disabled = true;
    $("messageInput").value = "";
    renderMessage("user", text.trim());
    const typing = renderMessage("assistant", "Estou pensando...");
    typing.classList.add("typing");
    try {
      const result = await api("chat", "POST", { message: text.trim() });
      typing.remove();
      renderMessage("assistant", result.answer);
      if (voiceEnabled) speakText(result.answer);
    } catch (e) {
      typing.remove();
      renderMessage("assistant", `Não consegui concluir sua solicitação. ${e.message}`);
    } finally {
      busy = false;
      $("sendButton").disabled = false;
      $("messageInput").focus();
    }
  }

  function speakText(text) {
    if (!("speechSynthesis" in window)) { toast("Este navegador não oferece síntese de voz."); return; }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "pt-BR";
    utterance.rate = 1;
    const voices = window.speechSynthesis.getVoices();
    const pt = voices.find(v => v.lang.toLowerCase().startsWith("pt"));
    if (pt) utterance.voice = pt;
    window.speechSynthesis.speak(utterance);
  }

  function setupVoice() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      $("micButton").disabled = true;
      $("voiceToggle").disabled = true;
      $("voiceToggle").textContent = "Voz indisponível";
      return;
    }
    recognition = new SpeechRecognition();
    recognition.lang = "pt-BR";
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      $("messageInput").value = transcript;
      sendMessage(transcript);
    };
    recognition.onerror = () => toast("Não consegui reconhecer a fala. Confira a permissão do microfone.");
    recognition.onend = () => $("micButton").classList.remove("recording");
    $("micButton").addEventListener("click", () => {
      try { $("micButton").classList.add("recording"); recognition.start(); }
      catch (_) { $("micButton").classList.remove("recording"); }
    });
    $("voiceToggle").addEventListener("click", () => {
      voiceEnabled = !voiceEnabled;
      $("voiceToggle").classList.toggle("enabled", voiceEnabled);
      $("voiceToggle").innerHTML = voiceEnabled ? "<span>◖</span> Voz ativada" : "<span>◖</span> Voz desativada";
      toast(voiceEnabled ? "As respostas serão faladas." : "Respostas por voz desativadas.");
    });
  }

  $("authSwitch").addEventListener("click", () => setAuthMode(!isRegister));
  $("authForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    $("authError").textContent = "";
    const data = { email: $("email").value.trim(), password: $("password").value };
    if (isRegister) data.display_name = $("displayName").value.trim();
    try {
      const result = await api(isRegister ? "register" : "login", "POST", data);
      user = result.user;
      await showApp();
      toast(isRegister ? "Conta criada. Bem-vindo!" : "Login realizado.");
    } catch (e) { $("authError").textContent = e.message; }
  });

  $("logoutButton").addEventListener("click", async () => {
    try { await api("logout", "POST", {}); window.location.reload(); }
    catch (e) { toast(e.message); }
  });

  $("chatForm").addEventListener("submit", (event) => {
    event.preventDefault();
    sendMessage($("messageInput").value);
  });
  $("messageInput").addEventListener("keydown", (event) => {
    if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); $("chatForm").requestSubmit(); }
    if (event.key === "Enter" && event.shiftKey) return;
  });
  $("newChatButton").addEventListener("click", async () => {
    if (!window.confirm("Começar uma nova conversa? O histórico atual será apagado desta conta.")) return;
    try { await api("clear_history", "POST", {}); await loadHistory(); toast("Histórico limpo."); }
    catch (e) { toast(e.message); }
  });
  document.querySelectorAll(".nav-button").forEach(button => {
    button.addEventListener("click", () => {
      document.querySelectorAll(".nav-button").forEach(b => b.classList.remove("active"));
      button.classList.add("active");
      const panel = button.dataset.panel;
      $("chatPanel").classList.toggle("hidden", panel !== "chatPanel");
      $("memoryPanel").classList.toggle("hidden", panel !== "memoryPanel");
      $("pageTitle").textContent = panel === "chatPanel" ? "Como posso ajudar?" : "Sua memória pessoal";
    });
  });
  document.querySelectorAll(".suggestion").forEach(button => {
    button.addEventListener("click", () => {
      $("messageInput").value = button.dataset.prompt;
      $("chatForm").requestSubmit();
    });
  });
  $("memoryForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      await api("memory_create", "POST", { title: $("memoryTitle").value, content: $("memoryContent").value });
      $("memoryForm").reset();
      await loadMemories();
      toast("Informação guardada na sua memória.");
    } catch (e) { toast(e.message); }
  });
  $("memoryEnabled").addEventListener("change", async () => {
    try {
      const result = await api("memory_toggle", "POST", { enabled: $("memoryEnabled").checked });
      user.memory_enabled = result.enabled ? 1 : 0;
      toast(result.enabled ? "Memórias ativadas." : "Memórias desativadas.");
    } catch (e) { toast(e.message); $("memoryEnabled").checked = ! $("memoryEnabled").checked; }
  });

  async function boot() {
    setupVoice();
    try {
      const state = await api("me");
      if (state.authenticated) { user = state.user; await showApp(); }
      else { $("authView").classList.remove("hidden"); $("appView").classList.add("hidden"); }
    } catch (e) {
      $("authError").textContent = "Não foi possível conectar ao servidor PHP. " + e.message;
    }
  }
  boot();
})();
