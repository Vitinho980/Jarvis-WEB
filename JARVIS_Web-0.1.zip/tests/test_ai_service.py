import os
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "ai_service"))
import server  # noqa: E402


class JarvisAIServiceTests(unittest.TestCase):
    def test_build_request_preserves_history_and_memory_without_duplicate_prompt(self):
        instructions, messages = server.build_request({
            "prompt": "Qual é meu esporte favorito?",
            "history": [
                {"role": "user", "content": "Oi"},
                {"role": "assistant", "content": "Olá!"},
                {"role": "user", "content": "Qual é meu esporte favorito?"},
            ],
            "memories": [{"title": "Esporte", "content": "Handebol"}],
        })
        self.assertIn("Handebol", instructions)
        self.assertEqual(len(messages), 3)
        self.assertEqual(messages[-1]["content"], "Qual é meu esporte favorito?")

    def test_response_text_extraction(self):
        result = {
            "output": [{
                "type": "message",
                "content": [{"type": "output_text", "text": "Conexão online confirmada."}],
            }]
        }
        self.assertEqual(server.extract_response_text(result), "Conexão online confirmada.")

    def test_uses_responses_api_and_keeps_key_out_of_payload(self):
        fake_key = "test-secret-that-must-not-be-logged"
        with patch.object(server, "OPENAI_API_KEY", fake_key), \
             patch.object(server, "post_json", return_value={"output_text": "Tudo certo."}) as mocked:
            answer, provider = server.ask({
                "prompt": "Teste",
                "history": [{"role": "user", "content": "Teste"}],
                "memories": [],
            })
        self.assertEqual(answer, "Tudo certo.")
        self.assertEqual(provider, "openai")
        args, kwargs = mocked.call_args
        self.assertEqual(args[0], "https://api.openai.com/v1/responses")
        self.assertEqual(args[1]["model"], "gpt-6-luna")
        self.assertFalse(args[1]["store"])
        self.assertNotIn(fake_key, str(args[1]))
        self.assertEqual(kwargs["headers"]["Authorization"], f"Bearer {fake_key}")

    def test_missing_key_has_actionable_message_without_leaking_a_value(self):
        with patch.object(server, "OPENAI_API_KEY", ""):
            with self.assertRaises(server.AIServiceError) as context:
                server.ask({"prompt": "Teste", "history": [], "memories": []})
        self.assertIn("OPENAI_API_KEY", context.exception.public_message)


if __name__ == "__main__":
    unittest.main()
