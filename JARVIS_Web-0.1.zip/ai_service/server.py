#!/usr/bin/env python3
"""Serviço interno de IA do JARVIS. A chave OpenAI existe somente neste processo."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import hmac
import json
import os
import urllib.error
import urllib.request

HOST = os.getenv("AI_SERVICE_HOST", "127.0.0.1")
PORT = int(os.getenv("AI_SERVICE_PORT", "8765"))
TOKEN = os.getenv("AI_SERVICE_TOKEN", "")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-6-luna").strip() or "gpt-6-luna"
OPENAI_RESPONSES_URL = "https://api.openai.com/v1/responses"

SYSTEM_PROMPT = (
    "Você é JARVIS, um assistente pessoal claro, educado e objetivo. "
    "Responda em português brasileiro, com explicações organizadas e sem inventar fatos. "
    "Use as memórias somente como contexto quando forem relevantes. "
    "Nunca peça senhas, códigos de autenticação ou dados financeiros sensíveis. "
    "Não afirme que executou ações no computador: este serviço apenas conversa."
)


class AIServiceError(Exception):
    """Erro seguro para devolver à interface sem expor chave ou detalhes internos."""

    def __init__(self, message: str, status: int = 503):
        super().__init__(message)
        self.public_message = message
        self.status = status


def post_json(url, payload, headers=None, timeout=60):
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=body,
        headers={"Content-Type": "application/json", **(headers or {})},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            raw = response.read().decode("utf-8")
            return json.loads(raw)
    except urllib.error.HTTPError as exc:
        # Não devolve nem registra o corpo bruto do provedor: ele não é necessário
        # para diagnosticar os erros mais comuns e evita expor detalhes sensíveis.
        if exc.code == 401:
            raise AIServiceError(
                "A OpenAI recusou a chave. Confira OPENAI_API_KEY em Tools → Secrets do Replit.",
                401,
            ) from None
        if exc.code == 403:
            raise AIServiceError(
                "A chave foi reconhecida, mas não tem permissão para usar a API/modelo. Confira o projeto e o acesso à API na OpenAI.",
                403,
            ) from None
        if exc.code == 404:
            raise AIServiceError(
                f"O modelo '{OPENAI_MODEL}' não foi encontrado ou não está disponível para esta chave. Confira OPENAI_MODEL.",
                404,
            ) from None
        if exc.code == 429:
            raise AIServiceError(
                "A OpenAI limitou a solicitação ou a conta da API está sem crédito disponível. Confira o limite e o faturamento da API.",
                429,
            ) from None
        if exc.code == 400:
            raise AIServiceError(
                "A OpenAI recusou os parâmetros da solicitação. Confira o modelo configurado e tente novamente.",
                400,
            ) from None
        if exc.code >= 500:
            raise AIServiceError(
                "A API da OpenAI está temporariamente indisponível. Tente novamente mais tarde.",
                502,
            ) from None
        raise AIServiceError(
            f"A API da OpenAI respondeu com erro HTTP {exc.code}.", 502
        ) from None
    except (urllib.error.URLError, TimeoutError, OSError):
        raise AIServiceError(
            "Não foi possível conectar à API da OpenAI. Verifique a conexão do Replit e tente novamente.",
            502,
        ) from None
    except json.JSONDecodeError:
        raise AIServiceError(
            "A API da OpenAI retornou uma resposta inválida. Tente novamente.", 502
        ) from None


def build_request(data):
    """Monta as instruções, o histórico e as memórias sem duplicar a mensagem atual."""
    memories = data.get("memories", [])
    history = data.get("history", [])
    prompt = str(data.get("prompt", "")).strip()
    if not prompt or len(prompt) > 4000:
        raise ValueError("Mensagem vazia ou muito longa.")

    memory_lines = []
    for item in memories[:20]:
        if isinstance(item, dict):
            title = str(item.get("title", "Memória"))[:80]
            content = str(item.get("content", ""))[:500]
            memory_lines.append(f"- {title}: {content}")

    instructions = SYSTEM_PROMPT
    if memory_lines:
        instructions += "\n\nInformações que o usuário escolheu salvar:\n" + "\n".join(memory_lines)

    input_messages = []
    for item in history[-14:]:
        if not isinstance(item, dict):
            continue
        role = item.get("role")
        content = item.get("content")
        if role in ("user", "assistant") and isinstance(content, str):
            input_messages.append({"role": role, "content": content[:4000]})

    # O PHP já inclui a mensagem atual no histórico persistido.
    if not input_messages or input_messages[-1].get("role") != "user" or input_messages[-1].get("content") != prompt:
        input_messages.append({"role": "user", "content": prompt})

    return instructions, input_messages


def extract_response_text(result):
    """Extrai texto da estrutura de saída da Responses API."""
    direct_text = result.get("output_text")
    if isinstance(direct_text, str) and direct_text.strip():
        return direct_text.strip()

    pieces = []
    for output_item in result.get("output", []):
        if not isinstance(output_item, dict) or output_item.get("type") != "message":
            continue
        for content_item in output_item.get("content", []):
            if not isinstance(content_item, dict):
                continue
            if content_item.get("type") in ("output_text", "text"):
                text = content_item.get("text")
                if isinstance(text, str) and text:
                    pieces.append(text)
    return "\n".join(pieces).strip()


def ask(data):
    if not OPENAI_API_KEY:
        raise AIServiceError(
            "A variável OPENAI_API_KEY não está configurada. Abra Tools → Secrets no Replit, crie esse segredo e reinicie o projeto.",
            503,
        )

    instructions, input_messages = build_request(data)
    result = post_json(
        OPENAI_RESPONSES_URL,
        {
            "model": OPENAI_MODEL,
            "instructions": instructions,
            "input": input_messages,
            "max_output_tokens": 900,
            # O histórico e as memórias já são mantidos pelo SQLite do JARVIS.
            "store": False,
        },
        headers={"Authorization": f"Bearer {OPENAI_API_KEY}"},
        timeout=60,
    )
    answer = extract_response_text(result)
    if not answer:
        raise AIServiceError(
            "A API respondeu, mas não retornou texto. Tente reformular a mensagem.", 502
        )
    return answer[:6000], "openai"


class Handler(BaseHTTPRequestHandler):
    server_version = "JarvisAI/2.0"

    def send_json(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/health":
            self.send_json(200, {
                "ok": True,
                "service": "jarvis-ai",
                "provider": "openai",
                "model": OPENAI_MODEL,
                "configured": bool(OPENAI_API_KEY),
            })
        else:
            self.send_json(404, {"ok": False, "error": "Not found"})

    def do_POST(self):
        if self.path != "/chat":
            self.send_json(404, {"ok": False, "error": "Not found"})
            return
        received = self.headers.get("X-Jarvis-Token", "")
        if not TOKEN or not hmac.compare_digest(received, TOKEN):
            self.send_json(403, {"ok": False, "error": "Forbidden"})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 100_000:
                self.send_json(413, {"ok": False, "error": "Payload too large"})
                return
            data = json.loads(self.rfile.read(length).decode("utf-8"))
            answer, provider = ask(data)
            self.send_json(200, {"ok": True, "answer": answer, "provider": provider, "model": OPENAI_MODEL})
        except AIServiceError as exc:
            self.send_json(exc.status, {"ok": False, "error": exc.public_message})
        except (ValueError, json.JSONDecodeError) as exc:
            self.send_json(400, {"ok": False, "error": str(exc)[:180]})
        except Exception as exc:
            # Registra apenas a classe da exceção; nunca imprime cabeçalhos, chave ou prompt.
            print(f"[JARVIS AI] falha interna: {type(exc).__name__}")
            self.send_json(502, {"ok": False, "error": "Falha interna no serviço de IA. Confira o console do Replit."})

    def log_message(self, fmt, *args):
        print("[JARVIS AI] " + fmt % args)


if __name__ == "__main__":
    if not TOKEN:
        raise SystemExit("AI_SERVICE_TOKEN ausente. Inicie o projeto usando bash start.sh.")
    print(f"JARVIS AI ouvindo em http://{HOST}:{PORT} | provedor=OpenAI | modelo={OPENAI_MODEL} | chave_configurada={bool(OPENAI_API_KEY)}")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
