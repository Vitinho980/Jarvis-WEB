# J.A.R.V.I.S. Web — Assistente pessoal com IA online

Aplicação web com interface responsiva, cadastro/login, banco SQLite, histórico por usuário, memória opt-in, reconhecimento de voz do navegador e respostas faladas. A interface continua em HTML/CSS/JavaScript, a autenticação e o histórico continuam em PHP, e um pequeno serviço Python faz a chamada segura à OpenAI.

**Não é necessário instalar nem executar Ollama.** O JARVIS usa a OpenAI Responses API como provedor principal.

## O que foi ajustado

- Removida a dependência do Ollama e a tentativa de carregar `qwen2.5:3b`.
- O serviço Python lê `OPENAI_API_KEY` diretamente do ambiente e chama `https://api.openai.com/v1/responses`.
- O modelo padrão foi atualizado para `gpt-6-luna` (`OPENAI_MODEL`).
- A chave fica somente no servidor Python. Ela não é enviada ao navegador, não aparece no JavaScript e não é impressa nos logs.
- A interface, login, chat, histórico SQLite e memória opcional foram mantidos.
- O histórico e as memórias continuam vindo do banco do JARVIS; o pedido à OpenAI usa `store: false`.
- O arquivo `.replit` inicia os dois serviços com o botão **Run**. O token interno entre PHP e Python é gerado automaticamente a cada inicialização, caso não exista um `AI_SERVICE_TOKEN` configurado.

## 1. Abrir no Replit

1. Importe/encontre o projeto no Replit e deixe os arquivos na raiz do projeto, incluindo `.replit`, `replit.nix` e `start.sh`.
2. O Replit instalará as dependências definidas em `replit.nix` (PHP com `pdo_sqlite`, `curl` e `mbstring`, além de Python 3). Se pedir para recarregar o ambiente, aceite.
3. Abra **Tools → Secrets** (em algumas telas aparece como **Secrets** dentro de **Setup**).
4. Crie um segredo com o nome exato `OPENAI_API_KEY` e cole nele sua chave da API OpenAI.
5. Pressione **Run**. O comando `bash start.sh` inicia o serviço Python de IA e depois o servidor PHP, que disponibiliza a interface na porta 8080.

Não escreva a chave em `app.js`, `index.php`, `.replit`, `README.md` ou em mensagens de chat. Não compartilhe capturas de tela do valor do Secret. A chave fica protegida no ambiente do servidor.

> A API da OpenAI é cobrada separadamente do ChatGPT. Verifique os créditos, o limite de gastos e as condições da sua conta antes de usar. Não coloque mais crédito do que pretende gastar.

## 2. Modelo configurado

O identificador padrão está definido em `OPENAI_MODEL=gpt-6-luna`. É o ID de API, não o nome comercial exibido na interface. A documentação atual da OpenAI apresenta GPT-6 Luna como opção de menor custo para tarefas focadas e de alto volume.

Para mudar o modelo, altere `OPENAI_MODEL` no ambiente do Replit (ou no `.env` para execução local) para outro ID que sua conta tenha permissão para usar. Não é preciso editar `app.js`.

## 3. Testar os serviços

Com o Replit rodando, abra o Shell e execute:

```bash
curl http://127.0.0.1:8765/health
```

A resposta deve conter campos semelhantes a estes:

```json
{"ok":true,"service":"jarvis-ai","provider":"openai","model":"gpt-6-luna","configured":true}
```

`configured: true` confirma somente que o processo recebeu uma variável de chave; não exibe a chave e ainda não comprova que ela é válida. O teste real é enviar uma mensagem pelo chat.

Depois, abra o Preview do Replit, crie uma conta ou entre, e envie:

> Olá, JARVIS. Responda apenas: conexão online confirmada.

O JARVIS deve responder pela OpenAI. Em seguida, abra **Minha memória**, salve uma informação de teste e faça uma pergunta relacionada a ela com a opção de uso da memória ativada. Isso valida a integração de contexto sem alterar a estrutura do chat.

## 4. Diagnóstico de erros

- **`configured: false`**: o segredo não está disponível para o processo. Confirme o nome `OPENAI_API_KEY` em Tools → Secrets e pressione Run novamente.
- **HTTP 401**: chave inválida, revogada ou copiada incorretamente. Atualize o Secret sem mostrá-lo nos logs.
- **HTTP 403**: a chave não tem acesso à API/modelo ou o projeto da OpenAI não tem as permissões necessárias.
- **HTTP 404 / modelo não encontrado**: verifique se `OPENAI_MODEL` está escrito exatamente como o ID disponível para sua conta.
- **HTTP 429**: limite de requisições, orçamento/crédito ou faturamento da API. Verifique a página de uso e limites da OpenAI.
- **Serviço PHP não inicia**: confira `php -v` e `php -m`. O PHP precisa das extensões `pdo_sqlite`, `curl` e `mbstring`.
- **Falha ao acessar `127.0.0.1:8765`**: inicie os serviços pelo botão Run ou execute `bash start.sh`; não inicie somente o PHP.

Se usar o app publicado, confira também os **Production/Deployment Secrets** do Replit: os Secrets do workspace/Preview e os da publicação podem ser separados. Adicione `OPENAI_API_KEY` aos Secrets da publicação e publique novamente.

## 5. Execução local (opcional)

O Ollama não é necessário. Em um computador com PHP 8+, extensões `pdo_sqlite`, `curl`, `mbstring` e Python 3:

```bash
cp .env.example .env
```

Coloque a chave no arquivo `.env` local (ele está no `.gitignore`) ou exporte `OPENAI_API_KEY` no terminal. Depois execute:

```bash
bash start.sh
```

Abra `http://127.0.0.1:8080`. O `start.sh` também aceita variáveis do ambiente e dá prioridade a elas sobre as do `.env`.

## 6. Como a memória e o histórico funcionam

- O histórico continua salvo na tabela `chat_messages`, separado por usuário.
- As memórias continuam salvas na tabela `memories` e só são enviadas ao modelo quando a opção de memória está ativada.
- O serviço Python recebe o histórico recente e até 20 memórias, como antes.
- A opção `store: false` é enviada à Responses API; a persistência da conversa no app continua sob controle do SQLite do JARVIS.
- Como a IA é online, o texto da mensagem, as mensagens recentes e as memórias habilitadas são enviados à OpenAI para gerar a resposta.

## Estrutura principal

```text
JARVIS_Web/
├── .replit
├── replit.nix
├── start.sh
├── .env.example
├── README.md
├── database/schema.sql
├── backend/
│   ├── bootstrap.php
│   └── ai_client.php
├── ai_service/server.py
└── public/
    ├── index.php
    ├── api.php
    └── assets/
        ├── app.css
        └── app.js
```
